#!/bin/bash

gcc assignment_4.c -o assignment_4
./assignment_4
