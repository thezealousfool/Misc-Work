#!/bin/bash

gcc assignment_1_b.c -o assignment_1_b
./assignment_1_b
