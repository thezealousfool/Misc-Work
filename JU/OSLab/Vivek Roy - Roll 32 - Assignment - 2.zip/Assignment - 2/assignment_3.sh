#!/bin/bash

gcc assignment_3.c -o assignment_3
./assignment_3
