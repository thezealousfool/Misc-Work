#!/bin/bash

gcc assignment_1_a.c -o assignment_1_a
./assignment_1_a
